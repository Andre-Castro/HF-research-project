For the URL Lists
-----------------
When the url's were written to the file, some URl's contained commas in them.
This means that when they are viewed in an excel spreadsheet they appear to
add extra collumns to that specific row. For example: 
(lines 209 in the excel spreadsheet for wilders)

       |         |                                  |      |         |        |
343924 | 2206062 |  http://www.pcmag.com/article2/0 | 2817 | 2416559 | 00.asp | 1
       |         |                                  |      |         |        | 

has these such columns when it should have:


       |         |                                                      |
343924 | 2206062 |  http://www.pcmag.com/article2/0,2817,2416559,00.asp | 1
       |         |                                                      | 

Just know that if this happens, the right most collumn (the "1" in this case)
is the number of instances. Regardless if the url Accidentally splits up into
multiple columns, the right most collumn will always be the number of instances.


Also, the current URL grabbing scheme seems to work better for wilders and
offcomm than it does for hackthissite. There are alot more weird looking URL's
found in the hackthis site forum than the other two. Just by scrolling through
and looking at the urls, it may just be due to each forums post guidelines
(wilders at least seems to be a more serious forum, hackthis site has many
silly urls like "www.xxxxxx.com/x.doc" and "http://"+server+"/events"")



For the IP Lists
-----------------
Offcomm has a couple posts where people have posted (According to the excel)
1,000+ IP's. I've checked a couple of these posts, they do indeed have a
rediculous amount of IP's and I didnt count exactly but 1,000+ posts seemed
about right.